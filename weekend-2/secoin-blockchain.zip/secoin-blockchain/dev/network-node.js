//This is our blockchain SERVER DISTRIBUTED NETWORK: expose our blockchain functions to the web browser.

//From npmjs web page.
const Blockchain = require('./blockchain.js');
const bodyParser = require('body-parser');
const secoin = new Blockchain();

const { v4: uuidv4 } = require('uuid');
const port = process.argv[2];
const rp = require('request-promise');
const nodeAddress = uuidv4().split('-').join('');

const express = require('express');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//Request and recieves response.
app.get('/', function (req, res) {
    res.send('Hello World')
})

//Blockchain endpoint.
app.get('/blockchain', function (req, res) {
    //Get is our HTTP function and accessing en "endpoint". Blockchain is the name.
    //res.send('Hello, Blockchain Build on Javascript (Node.js & Express.js)');
    res.send(secoin);
    //res = the SERVER/API's response
});

//Transaction endpoint.
app.post('/transaction', function (req, res) {
    const newTransaction = req.body;
    const blockIndex = secoin.addTransactionToPendingTransactions(newTransaction); //this returns the index
    res.json({ note: `transaction will be added in block ${blockIndex} ` });
    //This will "send in" our transaction. 
    //The 'req' is everything we send with the Postman app:
    //const blockIndex = secoin.createNewTransaction(req.body.amount, req.body.sender, req.body.recipient);
    //The 'res':
    //res.json({ note: `Transaction is added on block ${blockIndex}.` });
});

app.post('/transaction/broadcast', function(req, res) {
    const newTransaction = secoin.createNewTransaction(req.body.amount, req.body.sender, req.body.recipient);

    secoin.addTransactionToPendingTransactions(newTransaction);

    const requestPromises = [];
    secoin.networkNodes.forEach(networkNodeUrl => {
        const requestOptions = {
            uri: networkNodeUrl + '/transaction',
            method: 'POST',
            body: newTransaction,
            json: true
        };
        requestPromises.push(rp(requestOptions));
    });

    Promise.all(requestPromises)
        .then(data => {
            res.json({ note: 'transaction created and broadcast successfully' })
        });
});

//Mine - Chain endpoint.
app.get('/mine', function (req, res) {
    //Mine = validate out tx into the chain.
    const lastBlock = secoin.getLastBlock(); //Get the last block. (1)
    const previousBlockHash = lastBlock['hash']; //0
    //All the pending transactions
    const currentBlockData = {
        transactions: secoin.pendingTransactions,
        index: lastBlock['index'] + 1
    };

    //Calculate a new block
    const nonce = secoin.proofOfWork(previousBlockHash, currentBlockData);
    const blockHash = secoin.hashBlock(previousBlockHash, currentBlockData, nonce);

    //Create a new block.
    const newBlock = secoin.createNewBlock(nonce, previousBlockHash, blockHash);
    //Mining reward. 00 is a code from certain sender. The server address from where the clic is done.
    const requestPromises = [];

    secoin.networkNodes.forEach(networkNodeUrl => {
        console.log(networkNodeUrl);
        const requestOptions = {
            uri: networkNodeUrl + '/receive-new-block',
            method: 'POST',
            body: { newBlock: newBlock },
            json: true
        }
        requestPromises.push(rp(requestOptions));
    });
    Promise.all(requestPromises)
        .then(data => {
            const requestOptions = {
                uri: secoin.currentNodeUrl + '/transaction/broadcast',
                method: 'POST',
                body: {
                    amount: 6.25,
                    sender: "00",
                    recipient: nodeAddress
                },
                json: true
            }
            return rp(requestOptions);
        })
        .then(data => {
            res.json({
                note: 'new block mined and broadcast successfully',
                block: newBlock
            });
        });
});

//Recieve a new block
app.post('/receive-new-block', function(req, res) {
    const newBlock = req.body.newBlock;
    const lastBlock = secoin.getLastBlock();
    //Check hash
    const correctHash = lastBlock.hash === newBlock.previousBlockHash;
    //Check index
    const correctIndex = lastBlock['index'] + 1 === newBlock['index'];

    //Validate the package
    if (correctHash && correctIndex) {
        secoin.chain.push(newBlock);
        secoin.pendingTransactions = [];
        res.json({
            note: 'new block received and accepted',
            'newBlock': newBlock
        });
    } else {
        res.json({
            note: 'new block rejected',
            newBlock: newBlock
        })
    }
});

//Register a node and broadcast that nonde to the entire network
//Doctor, doctor, doctor.
//register a node and broadcast that node to the entire network
//doctor, doctor, doctor, doctor,... 
app.post('/register-and-broadcast-node', function (req, res) {

    //Recive the name of the recipent (join the network).
    const newNodeUrl = req.body.newNodeUrl;

    //Check if the recipient is not already part or the network.
    //!Need networkNodes info on blockchain.js!
    if (secoin.networkNodes.indexOf(newNodeUrl) == -1) secoin.networkNodes.push(newNodeUrl); //If not, add it.
    
    //Async computing. Not refresh all. !Instal library
    const regNodesPromises = [];

    //Build our list of network nodes. Doctor.
    secoin.networkNodes.forEach(networkNodeUrl => {
        //hit the register node endpoint
        const requestOptions = {
            uri: networkNodeUrl + '/register-node',
            method: 'POST',
            body: { newNodeUrl: newNodeUrl },
            json: true
        }
        regNodesPromises.push(rp(requestOptions));
    });
    //Sends it all together as a package.
    Promise.all(regNodesPromises)
        .then(data => {
            //use the data
            const bulkRegisterOptions = {
                uri: newNodeUrl + '/register-nodes-bulk',
                method: 'POST',
                body: { allNetworkNodes: [...secoin.networkNodes, secoin.currentNodeUrl] },
                json: true
            }
            return rp(bulkRegisterOptions);
        })
        .then(data => {
            res.json({ note: 'new node registered with network successfully' });
        });

});

//register a node with the network
app.post('/register-node', function(req, res) {
    const newNodeUrl = req.body.newNodeUrl; //take the new node url from the body
    const nodeNotAlreadyPresent = secoin.networkNodes.indexOf(newNodeUrl) == -1;
    const notCurrentNode = secoin.currentNodeUrl !== newNodeUrl;
    if (nodeNotAlreadyPresent && notCurrentNode) secoin.networkNodes.push(newNodeUrl);
    res.json({ note: 'new node registered successfully' });
});

//register multiple nodes at once
app.post('/register-nodes-bulk', function(req, res) {
    const allNetworkNodes = req.body.allNetworkNodes;

    allNetworkNodes.forEach(networkNodeUrl => {
        const nodeNotAlreadyPresent = secoin.networkNodes.indexOf(networkNodeUrl) == -1;
        const notCurrentNode = secoin.currentNodeUrl !== networkNodeUrl;
        if (nodeNotAlreadyPresent && notCurrentNode) secoin.networkNodes.push(networkNodeUrl);
    });
    res.json({ note: 'bulk registration successful' });
});

app.get('/consensus', function(req, res) {
    const requestPromises = [];

    //the first thing we do is make requests to all the other nodes on the network. 
    secoin.networkNodes.forEach(networkNodeUrl => {
        const requestOptions = {
            uri: networkNodeUrl + '/blockchain',
            method: "GET", //has no body on a get request
            json: true
        };
        requestPromises.push(rp(requestOptions));
    });

    //this loads up our array of all the blockchains 
    Promise.all(requestPromises)
        .then(blockchains => {
            //this blockchains is an array of all the other blockchains from all the other nodes
            //now we iterate through to see which is the longest

            //we've got to set up some tracking variables for the loop to follow 
            const currentChainLength = secoin.chain.length;
            let maxChainLength = currentChainLength;
            let newLongestChain = null;
            let newPendingTransactions = null;

            //we iterate through all the blockchains in our nw looking for the longest one
            blockchains.forEach(blockchain => {
                //which is the longest? is any longer than ours? 
                if (blockchain.chain.length > maxChainLength) {
                    //this one is longer, so change up some variables
                    maxChainLength = blockchain.chain.length;
                    newLongestChain = blockchain.chain;
                    newPendingTransactions = blockchain.pendingTransactions;
                };

            });

            //now, if there wasn't a longer chain than ours, we do not replace. 
            //newLongestChain would remain null or if a longer invalid one was found...
            if (!newLongestChain || (newLongestChain && !secoin.chainIsValid(newLongestChain))) {
                res.json({
                    note: 'Current chain has not been replaced.',
                    chain: secoin.chain,
                });
                // } else if (newLongestChain && secoin.chainIsValid(newLongestChain)) {
            } else {
                //here we found a longer one so we replace ours with the longer one.
                secoin.chain = newLongestChain;
                secoin.pendingTransactions = newPendingTransactions;
                res.json({
                    note: 'This chain has  been replaced.',
                    chain: secoin.chain,
                });
            }
        });

});

app.get('/block/:blockHash', function(req, res) {
    //send in a block hash and get the block back

    //first thing is to access the passed in paramter
    //e.g. localhost:300X/block/890DSDSIJO998DDSDSB88BDSDS
    const blockHash = req.params.blockHash;

    //invoke our method to get null or the correct block 
    const correctBlock = secoin.getBlock(blockHash);
    res.json({
        block: correctBlock
    });
});

app.get('/transaction/:transactionId', function(req, res) {
    //send in a t/x id and get back the t/x details
    const transactionId = req.params.transactionId;
    const transactionData = secoin.getTransaction(transactionId); //this gives us the t/x and the block as an object
    res.json({
        transaction: transactionData.transaction,
        block: transactionData.block
    });
});

app.get('/address/:address', function(req, res) {
    //send in a specific address and get all the t/x associated with it: sent or received and the balance of this address' account
    const address = req.params.address;
    const addressData = secoin.getAddressData(address); //we get an object{} w t/x 
    res.json({
        addressData: addressData
    })
});

app.get('/block-explorer', function(req, res) {
    res.sendFile('./block-explorer/index.html', { root: __dirname }); //this 2nd argument says look into this directory we are already in and find that 1st file path. 
});

app.listen(port, function () {
    console.log(`Listening on port ${port} ...`)
})