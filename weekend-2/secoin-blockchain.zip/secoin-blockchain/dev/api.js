//This is our blockchain SERVER: expose our blockchain functions to the web browser.

//From npmjs web page.
const Blockchain = require('./blockchain.js');
const bodyParser = require('body-parser');
const secoin = new Blockchain();

const { v4: uuidv4 } = require('uuid');

const nodeAddress = uuidv4().split('-').join('');

const express = require('express');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//Request and recieves response.
app.get('/', function (req, res) {
    res.send('Hello World')
})

//Blockchain endpoint.
app.get('/blockchain', function (req, res) {
    //Get is our HTTP function and accessing en "endpoint". Blockchain is the name.
    //res.send('Hello, Blockchain Build on Javascript (Node.js & Express.js)');
    res.send(secoin);
    //res = the SERVER/API's response
});

//Transaction endpoint.
app.post('/transaction', function (req, res) {

    //This will "send in" our transaction. 
    //The 'req' is everything we send with the Postman app:
    const blockIndex = secoin.createNewTransaction(req.body.amount, req.body.sender, req.body.recipient);
    //The 'res':
    res.json({ note: `Transaction is added on block ${blockIndex}.` });
})

//Mine - Chain endpoint.
app.get('/mine', function (req, res) {
    //Mine = validate out tx into the chain.
    const lastBlock = secoin.getLastBlock(); //Get the last block. (1)
    const previousBlockHash = lastBlock['hash']; //0
    //All the pending transactions
    const currentBlockData = {
        transactions: secoin.pendingTransactions,
        index: lastBlock['index'] + 1 
    };

    //Calculate a new block
    const nonce = secoin.proofOfWork(previousBlockHash, currentBlockData);
    const blockHash = secoin.hashBlock(previousBlockHash, currentBlockData, nonce);

    //Create a new block.
    const newBlock = secoin.createNewBlock(nonce, previousBlockHash, blockHash);
    //Mining reward. 00 is a code from certain sender. The server address from where the clic is done.
    secoin.createNewTransaction(6.25, "00", nodeAddress);

    res.json({
        note: "new block mined successfully",
        block: newBlock
    });
})

app.listen(3000, function () {
    console.log("Listening on port 3000...")
})